import numpy as np
import pandas as pd
import os, json
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

class RecommendationSystem:
    CATEGORY_CONFIG = {
        'books':   {'creator': 'author', 'group': 'genre'},
        'movies':  {'creator': 'director', 'group': 'genre'},
        'courses': {'creator': 'instructor', 'group': 'category'}
    }

    def __init__(self, load_from_csv: bool = False, data_folder: str = 'data'):
        self.data_folder = os.path.join(os.getcwd(), data_folder)
        self.data = self._load_data(load_from_csv)
        self.user_preferences = {cat: [] for cat in self.CATEGORY_CONFIG}
        self.ai_models = {}
        self._build_ai_models()

    def _load_data(self, load_from_csv: bool) -> dict:
        if not load_from_csv: return self._get_sample_data()
        print(f"Loading data from CSVs in '{self.data_folder}'...")
        loaded_data = {}
        for cat in self.CATEGORY_CONFIG:
            try:
                df = pd.read_csv(os.path.join(self.data_folder, f"{cat}.csv"))
                df['tags'] = df['tags'].apply(lambda t: json.loads(t.replace("'", '"')) if isinstance(t, str) and t.startswith('[') else [x.strip() for x in str(t).split(',')])
                df['id'] = pd.to_numeric(df['id'], errors='coerce').fillna(0).astype(int)
                df.dropna(subset=['id', 'title'], inplace=True)
                loaded_data[cat] = df.to_dict('records')
                print(f"✓ Loaded {len(loaded_data[cat])} {cat}.")
            except FileNotFoundError:
                print(f"✗ {cat}.csv not found.")
                loaded_data[cat] = []
        return loaded_data

    def _build_ai_models(self):
        print("\n🧠 Building AI models...")
        for category, items in self.data.items():
            if not items: continue
            df = pd.DataFrame(items)
            cfg = self.CATEGORY_CONFIG[category]
            df['soup'] = df[cfg['group']].fillna('') + ' ' + df[cfg['creator']].fillna('') + ' ' + df['tags'].apply(lambda t: ' '.join(t))
            tfidf_matrix = TfidfVectorizer(stop_words='english').fit_transform(df['soup'])
            self.ai_models[category] = {
                'cosine_sim': cosine_similarity(tfidf_matrix),
                'indices': pd.Series(df.index, index=df['title']).drop_duplicates()
            }

    def get_recommendations(self, category: str, top_n: int = 10) -> list:
        if not self.user_preferences[category]:
            return sorted(self.data[category], key=lambda x: x.get('rating', 0), reverse=True)[:top_n]
        model = self.ai_models.get(category)
        liked_indices = [model['indices'][item['title']] for item in self.user_preferences[category] if item['title'] in model['indices']]
        if not model or not liked_indices: return []
        avg_sim_scores = model['cosine_sim'][liked_indices].mean(axis=0)
        score_tuples = sorted(list(enumerate(avg_sim_scores)), key=lambda x: x[1], reverse=True)
        liked_ids = {item['id'] for item in self.user_preferences[category]}
        recs = [{**self.data[category][idx], 'similarity': score} for idx, score in score_tuples if self.data[category][idx]['id'] not in liked_ids]
        return recs[:top_n]

    def get_similar_items(self, category: str, item_id: int, top_n: int = 10) -> list:
        model = self.ai_models.get(category)
        target_item = next((item for item in self.data[category] if item['id'] == item_id), None)
        if not model or not target_item or target_item['title'] not in model['indices']: return []
        idx = model['indices'][target_item['title']]
        score_tuples = sorted(list(enumerate(model['cosine_sim'][idx])), key=lambda x: x[1], reverse=True)
        recs = [{**self.data[category][i], 'similarity': score} for i, score in score_tuples if self.data[category][i]['id'] != item_id]
        return recs[:top_n]

    def add_preference(self, category: str, item_id: int):
        item = next((i for i in self.data[category] if i['id'] == item_id), None)
        if item and item['id'] not in {p['id'] for p in self.user_preferences[category]}:
            self.user_preferences[category].append(item)
            print(f"✓ Added '{item['title']}'.")
        elif item: print(f"⚠ '{item['title']}' is already in preferences.")
        else: print(f"❌ Item ID {item_id} not found.")

    def remove_preference(self, category: str, item_id: int):
        current_prefs = self.user_preferences[category]
        item = next((p for p in current_prefs if p['id'] == item_id), None)
        if item:
            self.user_preferences[category] = [p for p in current_prefs if p['id'] != item_id]
            print(f"✓ Removed '{item['title']}'.")
        else: print(f"❌ Item ID {item_id} not in preferences.")

    def display_items(self, items: list, category: str, title: str):
        print(f"\n--- {title.upper()} ---")
        if "Recommendations" in title or "Similar" in title:
            print("Similarity Score (0-1): How closely content matches your taste. Higher is better.")
        if not items:
            print("No items to display.")
            return
        cfg = self.CATEGORY_CONFIG[category]
        for item in items:
            sim_line = f"| Similarity: {item['similarity']:.2f}" if 'similarity' in item else ""
            print(f"\nID: {item['id']} | {item['title']} (Rating: {item.get('rating', 0):.1f}) {sim_line}\n  {cfg['creator'].title()}: {item.get(cfg['creator'], 'N/A')} | {cfg['group'].title()}: {item.get(cfg['group'], 'N/A')}")

    def _get_id_input(self, prompt: str) -> int | None:
        try: return int(input(prompt))
        except (ValueError, TypeError):
            print("Invalid ID.")
            return None

    def run(self):
        while True:
            print("\n" + "="*50 + "\n      AI PERSONALIZED RECOMMENDATION SYSTEM\n" + "="*50)
            menu_items = [f"{i+1}. {c.title()}" for i, c in enumerate(self.CATEGORY_CONFIG)] + [f"{len(self.CATEGORY_CONFIG) + 1}. Exit"]
            choice = input(" | ".join(menu_items) + "\n> ").strip()
            if choice == str(len(self.CATEGORY_CONFIG) + 1): break
            try: self._category_menu(list(self.CATEGORY_CONFIG.keys())[int(choice) - 1])
            except (ValueError, IndexError): print("Invalid choice.")

    def _category_menu(self, cat: str):
        menu = (f"\n--- {cat.upper()} MENU ---\n1. Get Recommendations\n2. Add Preferences\n3. Remove Preferences\n"
                f"4. Find Similar\n5. View Preferences\n6. View All\n7. Back\n> ")
        actions = {
            '1': lambda: self.display_items(self.get_recommendations(cat), cat, f"Recommendations for You" if self.user_preferences[cat] else f"Popular {cat}"),
            '2': lambda: (id := self._get_id_input("Enter ID to add: ")) is not None and self.add_preference(cat, id),
            '3': lambda: self.user_preferences[cat] and (id := self._get_id_input("Enter ID to remove: ")) is not None and self.remove_preference(cat, id),
            '4': lambda: (id := self._get_id_input("Enter ID to find similar items: ")) is not None and self.display_items(self.get_similar_items(cat, id), cat, f"Similar to Item ID {id}"),
            '5': lambda: self.display_items(self.user_preferences[cat], cat, f"Your {cat.title()} Preferences"),
            '6': lambda: self.display_items(self.data[cat], cat, f"All {cat.title()}")
        }
        while True:
            choice = input(menu).strip()
            if choice == '7': break
            action = actions.get(choice)
            if action: action()
            else: print("Invalid choice.")
    
    def _get_sample_data(self) -> dict:
        return {'books': [{'id':1,'title':'Project Hail Mary','author':'Andy Weir','genre':'Sci-Fi','tags':['space','science']}], 'movies': [{'id':1,'title':'Inception','director':'Christopher Nolan','genre':'Sci-Fi','tags':['mind-bending','action']}], 'courses': [{'id':1,'title':'Deep Learning Specialization','instructor':'Andrew Ng','category':'Data Science','tags':['ai','python']}]}

if __name__ == "__main__":
    choice = input("\nLoad data from:\n1. Sample Data\n2. CSV files in './data/'\n> ").strip()
    RecommendationSystem(load_from_csv=(choice == '2')).run()
    print("\nThank you for using the AI Recommender!")